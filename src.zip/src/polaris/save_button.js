import React from 'react';
import {Button} from '@shopify/polaris';

export default class Save extends React.Component {
  render() {
    return (
      <Button primary>Save Deatils</Button>
    );
  }
}
