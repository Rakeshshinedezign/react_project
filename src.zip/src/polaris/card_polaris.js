import React from 'react';
//import {Card} from '@shopify/polaris';
import {Card, Layout} from '@shopify/polaris';

export default class Head extends React.Component {
  render() {
    return (
      <Card title="Contact Us Form" sectioned>
  <p>Fill this form so that we can contact you.</p>
</Card>
    );
  }
}
