// import React from 'react';
// import {Card} from '@shopify/polaris';

// export default class Header extends React.Component {
//   render() {
//     return (
//       <Card title="Online store dashboard" sectioned>
//   <p>View a summary of your online store’s performance.</p>
// </Card>
//     );
//   }
// }

// import React from 'react';
// import {Button} from '@shopify/polaris';

// export default class Header extends React.Component {
//   render() {
//     return (
//       <Button size="large">Create store</Button>
//     );
//   }
// }



